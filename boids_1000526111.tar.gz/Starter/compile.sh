g++ -O4 -g -fopenmp Boids.cpp -L./lib -lglui -l3ds -I./include -lGL -lglut -lGLU -lm -o Boids
